package ru.vsu.cs.chernousov.classes;

public class AdministrativeEmployee extends Employee {
}